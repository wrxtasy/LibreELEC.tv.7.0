﻿/*
 * PLUGIN SeedingTime
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.seedingTime		= "完成时间";
 theUILang.addTime		= "添加时间";

thePlugins.get("seedingtime").langLoaded();
﻿/*
 * PLUGIN SeedingTime
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (pfactum@gmail.com)
 */

 theUILang.seedingTime		= "Завершено";
 theUILang.addTime		= "Додано";

thePlugins.get("seedingtime").langLoaded();
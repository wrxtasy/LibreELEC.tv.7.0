﻿/*
 * PLUGIN DATA
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.getData		= "Pobierz plik";
 theUILang.cantAccessData	= "User Webservera nie ma dostępu do plików tego torrenta.";

thePlugins.get("data").langLoaded();
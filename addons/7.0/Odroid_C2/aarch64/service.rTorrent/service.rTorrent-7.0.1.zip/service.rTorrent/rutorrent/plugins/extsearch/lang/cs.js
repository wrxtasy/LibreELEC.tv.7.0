﻿/*
 * PLUGIN EXTSEARCH
 *
 * Czech language file.
 *
 * Author: 
 */

 theUILang.tegMenuLoad			= "Load";
 theUILang.tegMenuOpen			= "Open in browser";
 theUILang.tegMenuDeleteItem		= "Remove item";
 theUILang.tegMenuDelete		= "Remove tag";
 theUILang.tegRefresh			= "Refresh tag";
 theUILang.exsGlobal			= "Include into 'All' category";
 theUILang.exsLimit			= "Result limit";
 theUILang.exsEngines			= "Engines";
 theUILang.exsSearch			= "Search";
 theUILang.exsGlobalLimit		= "Common Limitations";
 theUILang.excat			= "Category";
 theUILang.excatall			= "All";
 theUILang.excatmovies			= "Movies";
 theUILang.excattv			= "TV";
 theUILang.excatmusic			= "Music";
 theUILang.excatgames			= "Games";
 theUILang.excatanime			= "Anime";
 theUILang.excatsoftware		= "Software";
 theUILang.excatpictures		= "Pictures";
 theUILang.excatbooks			= "Books";
 theUILang.extPrivate			= "Private";
 theUILang.extPublic			= "Public";
 theUILang.exsCookies			= "Format of cookies";
 theUILang.extAllPublic 		= "All Public";
 theUILang.extAllPrivate		= "All Private";
 theUILang.exsMustInstallCookies	= "Cookies plugin is required to work with this engine.";
 theUILang.exsMustInstallLoginMgr	= "LoginMgr plugin is required to work with this engine.";
 theUILang.exsLoginMgr			= "Setup your account in LoginMgr plugin to work with this engine.";
 theUILang.exsURLInfo			= "URL info";
 theUILang.exsURLGUID			= "Description URL";
 theUILang.exsURLHref			= "Download URL";

thePlugins.get("extsearch").langLoaded();
﻿/*
 * PLUGIN SeedingTime
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.seedingTime		= "Finalizado";
 theUILang.addTime		= "Agregado";

thePlugins.get("seedingtime").langLoaded();